package com.example.topobt;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import java.util.*;

public class ToolsActivity extends Activity {
    private LinearLayout box; private TextView tvRes; private final List<EditText> fields=new ArrayList<>();
    private final List<Character> kinds=new ArrayList<>(); private TopoMath.Prog cur; private EditText multi;
    private CheckBox cbMulti; private int selectedProgram=0;
    private static final int NUM=InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setTitle("Programas de topografía");ScrollView sv=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,16);sv.addView(root);
        Spinner sp=new Spinner(this);String[] names=new String[TopoMath.PROGS.length];for(int i=0;i<names.length;i++)names[i]=TopoMath.PROGS[i].name;sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(sp);
        CheckBox cb=new CheckBox(this);cb.setText("Ángulos GG.MMSS (123.4530 = 123°45'30\")");cb.setChecked(TopoMath.gms);cb.setOnCheckedChangeListener((v,c)->TopoMath.gms=c);root.addView(cb);
        cbMulti=new CheckBox(this);cbMulti.setText("Ingresar varios PI consecutivos");root.addView(cbMulti);
        box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);root.addView(box);
        LinearLayout actions=new LinearLayout(this);Button measure=new Button(this);measure.setText("Medir punto");measure.setOnClickListener(v->{if(Store.measureAction!=null)Store.measureAction.run();else Toast.makeText(this,"Abre la pantalla principal para conectar",Toast.LENGTH_SHORT).show();});actions.addView(measure,new LinearLayout.LayoutParams(0,-2,1));
        Button calc=new Button(this);calc.setText("Calcular");calc.setOnClickListener(v->calcular());actions.addView(calc,new LinearLayout.LayoutParams(0,-2,1));root.addView(actions);
        tvRes=new TextView(this);tvRes.setTypeface(android.graphics.Typeface.MONOSPACE);tvRes.setTextIsSelectable(true);tvRes.setPadding(0,16,0,16);root.addView(tvRes);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){selectedProgram=pos;cbMulti.setVisibility(pos==6||pos==7?View.VISIBLE:View.GONE);build(pos);}public void onNothingSelected(AdapterView<?> p){}});
        cbMulti.setOnCheckedChangeListener((v,c)->{if(selectedProgram==6||selectedProgram==7)build(selectedProgram);});setContentView(sv);
    }
    private EditText edit(String hint,float weight){EditText e=new EditText(this);e.setInputType(NUM);e.setHint(hint);e.setSingleLine(true);if(weight>0)e.setLayoutParams(new LinearLayout.LayoutParams(0,-2,weight));return e;}
    private void build(int pos){cur=TopoMath.PROGS[pos];box.removeAllViews();fields.clear();kinds.clear();tvRes.setText("");multi=null;
        if(pos==8){buildArea();return;}
        if(cbMulti.isChecked()&&(pos==6||pos==7)){TextView help=new TextView(this);help.setText("Una fila por PI: N;E;Z;Az entrada;Az salida;Radio"+(pos==7?";Ls":"")+". Separador ;");box.addView(help);multi=new EditText(this);multi.setHint("N;E;Z;Az entrada;Az salida;Radio"+(pos==7?";Ls":"")+"\n...");multi.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);multi.setMinLines(4);box.addView(multi);addLatestButton(true);return;}
        for(String spec:cur.in){char t=spec.charAt(0);String label=spec.substring(2);if(t=='P'){
            TextView tv=new TextView(this);tv.setText(label);box.addView(tv);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            EditText n=edit("N",1),e=edit("E",1),z=edit("Z",1);row.addView(e);row.addView(n);row.addView(z);
            Button m=new Button(this);m.setText("Medir");m.setOnClickListener(v->measureInto(n,e,z));row.addView(m);
            Button pick=new Button(this);pick.setText("Leídos");pick.setOnClickListener(v->elegir(n,e,z));row.addView(pick);box.addView(row);
            fields.add(n);kinds.add('R');fields.add(e);kinds.add('R');fields.add(z);kinds.add('Z');
        }else{EditText e=edit(label+(t=='A'?" (°)":""),0);box.addView(e);fields.add(e);kinds.add(t=='A'?'A':'R');}}
    }
    private void buildArea(){TextView help=new TextView(this);help.setText("Añade al menos 3 puntos. Una fila por punto: E;N;Z");box.addView(help);multi=new EditText(this);multi.setHint("E;N;Z\nE;N;Z\nE;N;Z");multi.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);multi.setMinLines(5);box.addView(multi);addLatestButton(false);}
    private void addLatestButton(boolean pi){Button b=new Button(this);b.setText("Añadir último punto medido");b.setOnClickListener(v->{if(Double.isNaN(Store.lastN)){Toast.makeText(this,"Primero mide un punto desde la app",Toast.LENGTH_SHORT).show();return;}String line=selectedProgram==8?String.format(Locale.US,"%.3f;%.3f;%.3f",Store.lastE,Store.lastN,Store.lastZ):String.format(Locale.US,"%.3f;%.3f;%.3f",Store.lastN,Store.lastE,Store.lastZ);if(pi)line+=selectedProgram==7?";;;;":";;;";multi.append((multi.length()==0?"":"\n")+line);});box.addView(b);}
    private void measureInto(EditText n,EditText e,EditText z){if(Store.measureAction==null){Toast.makeText(this,"Conecta la estación desde la pantalla principal",Toast.LENGTH_SHORT).show();return;}Store.pointListener=p->{n.setText(String.format(Locale.US,"%.3f",p[0]));e.setText(String.format(Locale.US,"%.3f",p[1]));z.setText(String.format(Locale.US,"%.3f",p[2]));};Store.measureAction.run();}
    private void elegir(final EditText n,final EditText e,final EditText z){if(Store.points.isEmpty()){Toast.makeText(this,"Aún no hay puntos leídos",Toast.LENGTH_SHORT).show();return;}String[] items=new String[Store.points.size()];for(int i=0;i<items.length;i++){double[] q=Store.points.get(i);items[i]=String.format(Locale.US,"%s E=%.3f N=%.3f Z=%.3f",Store.names.get(i),q[1],q[0],q[2]);}
        new AlertDialog.Builder(this).setTitle("Puntos leídos").setItems(items,(d,i)->{double[] q=Store.points.get(i);n.setText(String.format(Locale.US,"%.3f",q[0]));e.setText(String.format(Locale.US,"%.3f",q[1]));z.setText(String.format(Locale.US,"%.3f",q[2]));}).show();}
    private void calcular(){if(multi!=null){calcularMultiple();return;}double[] v=new double[fields.size()];for(int i=0;i<v.length;i++){String s=fields.get(i).getText().toString().trim().replace(',','.');char k=kinds.get(i);if(s.isEmpty()||s.equals("-")||s.equals(".")){if(k=='Z'){v[i]=Double.NaN;continue;}tvRes.setText("Faltan datos por llenar.");return;}try{v[i]=Double.parseDouble(s);}catch(Exception ex){tvRes.setText("Número no válido: "+s);return;}if(k=='A')v[i]=TopoMath.ang(v[i]);}
        try{tvRes.setText(cur.run.run(v));}catch(Exception ex){tvRes.setText("Error de cálculo: "+ex.getMessage());}}
    private void calcularMultiple(){String[] lines=multi.getText().toString().split("\\r?\\n");List<double[]> pts=new ArrayList<>();StringBuilder result=new StringBuilder();boolean area=selectedProgram==8;int required=area?2:(selectedProgram==7?7:6);
        for(String line:lines){line=line.trim();if(line.isEmpty())continue;String[] parts=line.split("[;\\t]",-1);if(parts.length<required){tvRes.setText("Fila incompleta: "+line);return;}double[] a=new double[parts.length];try{int lim=area?Math.min(2,parts.length):parts.length;for(int i=0;i<lim;i++)a[i]=Double.parseDouble(parts[i].trim().replace(',','.'));if(!area)for(int i=0;i<a.length;i++)if(parts[i].trim().isEmpty())throw new NumberFormatException();}catch(Exception ex){tvRes.setText("Dato no numérico: "+line);return;}
            if(area){pts.add(new double[]{a[1],a[0],Double.NaN});continue;}
            double az1=TopoMath.ang(a[3]),az2=TopoMath.ang(a[4]);double[] v=selectedProgram==7?new double[]{a[0],a[1],a[2],az1,az2,a[5],a[6]}:new double[]{a[0],a[1],a[2],az1,az2,a[5]};
            result.append("PI ").append(pts.size()+1).append("\n").append(cur.run.run(v)).append("\n");pts.add(new double[]{a[0],a[1],a[2]});
        }
        if(area){double[][] a=pts.toArray(new double[0][]);tvRes.setText(TopoMath.area(a));}else if(pts.isEmpty())tvRes.setText("Ingrese al menos un PI.");else tvRes.setText(result.toString());
    }
    @Override protected void onDestroy(){super.onDestroy();Store.pointListener=null;}
}
